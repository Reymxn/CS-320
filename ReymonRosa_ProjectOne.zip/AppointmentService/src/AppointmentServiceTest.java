import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment =
                new Appointment("12345", futureDate, "Doctor Appointment");

        service.addAppointment(appointment);
    }

    @Test
    public void testDuplicateAppointmentId() {
        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment1 =
                new Appointment("12345", futureDate, "Doctor Appointment");

        Appointment appointment2 =
                new Appointment("12345", futureDate, "Dentist Appointment");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment =
                new Appointment("12345", futureDate, "Doctor Appointment");

        service.addAppointment(appointment);
        service.deleteAppointment("12345");
    }
}