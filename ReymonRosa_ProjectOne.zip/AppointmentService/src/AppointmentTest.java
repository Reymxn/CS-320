import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment =
                new Appointment("12345", futureDate, "Doctor Appointment");

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals("Doctor Appointment", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Doctor Appointment");
        });
    }

    @Test
    public void testPastDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Doctor Appointment");
        });
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                "12345",
                futureDate,
                "123456789012345678901234567890123456789012345678901"
            );
        });
    }

    @Test
    public void testNullValues() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Doctor Appointment");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Doctor Appointment");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });
    }
}