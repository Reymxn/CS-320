import java.util.ArrayList;

public class AppointmentService {

    private ArrayList<Appointment> appointments = new ArrayList<>();

    public void addAppointment(Appointment appointment) {

        for (Appointment existingAppointment : appointments) {
            if (existingAppointment.getAppointmentId().equals(appointment.getAppointmentId())) {
                throw new IllegalArgumentException("Appointment ID already exists");
            }
        }

        appointments.add(appointment);
    }

    public void deleteAppointment(String appointmentId) {

        Appointment appointmentToDelete = null;

        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentId().equals(appointmentId)) {
                appointmentToDelete = appointment;
            }
        }

        if (appointmentToDelete != null) {
            appointments.remove(appointmentToDelete);
        }
    }
}