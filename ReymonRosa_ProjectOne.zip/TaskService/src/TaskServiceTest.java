import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Homework", "Complete CS320 assignment");

        service.addTask(task);
    }

    @Test
    public void testDuplicateTaskId() {
        TaskService service = new TaskService();

        Task task1 = new Task("12345", "Homework", "Complete assignment");
        Task task2 = new Task("12345", "Project", "Finish project");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Homework", "Complete assignment");

        service.addTask(task);
        service.deleteTask("12345");
    }

    @Test
    public void testUpdateName() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Homework", "Complete assignment");

        service.addTask(task);
        service.updateName("12345", "Project");

        assertEquals("Project", task.getName());
    }

    @Test
    public void testUpdateDescription() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Homework", "Complete assignment");

        service.addTask(task);
        service.updateDescription("12345", "Finish CS320 milestone");

        assertEquals("Finish CS320 milestone", task.getDescription());
    }
}