import java.util.ArrayList;

public class TaskService {

    private ArrayList<Task> tasks = new ArrayList<>();

    public void addTask(Task task) {

        for (Task existingTask : tasks) {
            if (existingTask.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("Task ID already exists");
            }
        }

        tasks.add(task);
    }

    public void deleteTask(String taskId) {

        Task taskToDelete = null;

        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                taskToDelete = task;
            }
        }

        if (taskToDelete != null) {
            tasks.remove(taskToDelete);
        }
    }

    public void updateName(String taskId, String name) {

        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                task.setName(name);
            }
        }
    }

    public void updateDescription(String taskId, String description) {

        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                task.setDescription(description);
            }
        }
    }
}