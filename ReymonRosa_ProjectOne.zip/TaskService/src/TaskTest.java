import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("12345", "Homework", "Complete assignment");

        assertEquals("12345", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Complete assignment", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Homework", "Complete assignment");
        });
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "ABCDEFGHIJKLMNOPQRSTU", "Complete assignment");
        });
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework",
                    "123456789012345678901234567890123456789012345678901");
        });
    }

    @Test
    public void testNullValues() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Complete assignment");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Complete assignment");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework", null);
        });
    }
}